"""CLI entrypoint for the K-Means clustering application.

Example:
    python main.py --data data/sample_dataset.csv --context finance --k auto

Notes:
- If --k auto, the elbow method is used to recommend K.
- Outputs are written to ./outputs by default.
"""

from __future__ import annotations

import argparse
from pathlib import Path

from src.pipeline import run_pipeline


def build_arg_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(
        description="K-Means clustering pipeline with elbow method and charts"
    )
    parser.add_argument(
        "--data",
        type=str,
        required=True,
        help="Path to CSV file containing features",
    )
    parser.add_argument(
        "--context",
        type=str,
        choices=["finance", "marketing", "healthcare"],
        default="finance",
        help="Domain context to drive feature selection + KPI summaries",
    )
    parser.add_argument(
        "--k",
        type=str,
        default="auto",
        help="Number of clusters (e.g. 3) or 'auto' to use elbow recommendation",
    )
    parser.add_argument(
        "--outdir",
        type=str,
        default="outputs",
        help="Output directory for charts and CSV exports",
    )
    return parser


if __name__ == "__main__":
    args = build_arg_parser().parse_args()

    data_path = Path(args.data)
    outdir = Path(args.outdir)
    outdir.mkdir(parents=True, exist_ok=True)

    k_value: int | None
    if args.k.strip().lower() == "auto":
        k_value = None
    else:
        k_value = int(args.k)

    run_pipeline(
        data_path=data_path,
        context=args.context,
        outdir=outdir,
        k=k_value,
    )
