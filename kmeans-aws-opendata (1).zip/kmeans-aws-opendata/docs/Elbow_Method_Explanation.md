# Elbow Method (How K was Selected)

## What the elbow method measures
K-Means minimizes **inertia**, which is the *sum of squared distances* between each point and its assigned cluster center. As you increase the number of clusters **k**, inertia will always decrease (because more clusters can fit the data more tightly), but the improvement eventually becomes small.

## The decision idea
The "elbow" is the point where adding an extra cluster stops producing a *meaningful* reduction in inertia. In business terms, it is a practical balance between:
- **Accuracy / fit** (lower inertia)
- **Interpretability and actionability** (fewer clusters are easier to name and operationalize)

## How this project applies it
This repository computes inertia across a range of k values (default 2–10) and saves `outputs/<context>/elbow.png`. It then recommends a k using a simple, explainable heuristic:
- compute discrete second differences of inertia (curvature)
- choose the k with the highest curvature (largest "bend")

This approach is appropriate for an academic submission because it is transparent and easy to communicate to non-technical stakeholders.
