# K-Means Clustering Application (AWS Open Data)

A modular, testable K-Means clustering app built for PyCharm and GitHub submission.

## Quick start

```bash
python -m venv .venv
# Windows: .venvScripts\activate
# macOS/Linux: source .venv/bin/activate
pip install -r requirements.txt

# run the pipeline
python main.py --data data/sample_dataset.csv --context finance --k auto

# run unit tests
pytest -q
```

## Outputs
- `outputs/elbow.png` — inertia vs. K elbow chart
- `outputs/clusters_2d.png` — 2D projection chart
- `outputs/cluster_summary.csv` — per-cluster KPI averages
- `outputs/labeled_data.csv` — original data + Cluster label

## Folder structure
- `src/` — application modules
- `tests/` — unit tests (pytest)
- `data/` — sample data placeholder
- `docs/` — executive summaries (.docx)
- `outputs/` — generated charts and exports
