import numpy as np

from src.kmeans_model import compute_inertia_curve, fit_kmeans, recommend_k_elbow


def test_kmeans_output_length():
    X = np.array([[1, 2], [1, 4], [1, 0], [10, 2], [10, 4], [10, 0]], dtype=float)
    res = fit_kmeans(X, k=2)
    assert len(res.labels) == len(X)


def test_kmeans_cluster_count():
    rng = np.random.default_rng(42)
    X = rng.random((50, 3))
    res = fit_kmeans(X, k=3)
    assert len(set(res.labels.tolist())) == 3


def test_elbow_recommendation_returns_valid_k():
    rng = np.random.default_rng(0)
    X = rng.random((60, 4))
    ks, inertias = compute_inertia_curve(X, k_min=2, k_max=8)
    k_star = recommend_k_elbow(ks, inertias)
    assert k_star in ks
