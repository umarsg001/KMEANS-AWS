"""Preprocessing: validate columns, handle missing values, and scale features."""

from __future__ import annotations

from dataclasses import dataclass

import numpy as np
import pandas as pd
from sklearn.preprocessing import StandardScaler


@dataclass
class PreprocessResult:
    X: np.ndarray
    scaler: StandardScaler
    feature_names: list[str]


def validate_columns(df: pd.DataFrame, required: list[str]) -> None:
    missing = [c for c in required if c not in df.columns]
    if missing:
        raise ValueError(
            "Missing required columns for chosen domain context: " + ", ".join(missing)
        )


def coerce_numeric(df: pd.DataFrame, cols: list[str]) -> pd.DataFrame:
    out = df.copy()
    for c in cols:
        out[c] = pd.to_numeric(out[c], errors="coerce")
    return out


def preprocess(df: pd.DataFrame, feature_cols: list[str]) -> PreprocessResult:
    """Prepare feature matrix for K-Means.

    Steps:
    1) Validate columns
    2) Coerce to numeric
    3) Simple missing-value handling (median imputation)
    4) Standardize features (critical for Euclidean-distance clustering)
    """
    validate_columns(df, feature_cols)

    work = coerce_numeric(df, feature_cols)

    # Median imputation for stability and simplicity in an assignment setting
    medians = work[feature_cols].median(numeric_only=True)
    work[feature_cols] = work[feature_cols].fillna(medians)

    scaler = StandardScaler()
    X = scaler.fit_transform(work[feature_cols].values)

    return PreprocessResult(X=X, scaler=scaler, feature_names=list(feature_cols))
