"""Charting utilities.

Charts are intentionally simple (matplotlib only) and saved to disk for submission.
"""

from __future__ import annotations

from pathlib import Path

import matplotlib.pyplot as plt
import numpy as np
from sklearn.decomposition import PCA


def plot_elbow(ks: list[int], inertias: list[float], outpath: Path) -> None:
    plt.figure()
    plt.plot(ks, inertias, marker="o")
    plt.xlabel("Number of clusters (k)")
    plt.ylabel("Inertia (sum of squared distances)")
    plt.title("Elbow Method: Inertia vs k")
    plt.tight_layout()
    plt.savefig(outpath, dpi=200)
    plt.close()


def plot_clusters_2d(X: np.ndarray, labels: np.ndarray, outpath: Path) -> None:
    """Project high-dimensional X to 2D with PCA and plot clusters."""
    pca = PCA(n_components=2, random_state=42)
    X2 = pca.fit_transform(X)

    plt.figure()
    # Matplotlib default cycle colors; no manual colors (keeps it simple)
    for cluster_id in sorted(set(labels.tolist())):
        mask = labels == cluster_id
        plt.scatter(X2[mask, 0], X2[mask, 1], s=18, label=f"Cluster {cluster_id}")

    plt.xlabel("PC1")
    plt.ylabel("PC2")
    plt.title("K-Means Clusters (PCA 2D Projection)")
    plt.legend()
    plt.tight_layout()
    plt.savefig(outpath, dpi=200)
    plt.close()
