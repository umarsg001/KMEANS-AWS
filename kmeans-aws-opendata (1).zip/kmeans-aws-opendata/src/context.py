"""Domain contexts.

To satisfy the assignment requirement "customize strictly for Finance / Marketing / Healthcare",
this module defines **separate feature sets** and **KPI summaries** per domain.

You can replace the sample column names with real columns from your chosen AWS dataset.
"""

from __future__ import annotations

from dataclasses import dataclass


@dataclass(frozen=True)
class DomainContext:
    name: str
    features: list[str]
    kpis: list[str]


FINANCE = DomainContext(
    name="finance",
    # Typical finance clustering dimensions: customer value + risk + behavior
    features=[
        "monthly_spend",
        "avg_balance",
        "credit_utilization",
        "late_payments_12m",
        "transactions_90d",
    ],
    # KPIs to summarize per cluster (can overlap with features)
    kpis=[
        "monthly_spend",
        "avg_balance",
        "credit_utilization",
        "late_payments_12m",
        "churn_flag",
    ],
)

MARKETING = DomainContext(
    name="marketing",
    # Typical marketing segmentation dimensions: engagement + conversion + basket
    features=[
        "sessions_30d",
        "conversion_rate",
        "avg_order_value",
        "email_click_rate",
        "returns_rate",
    ],
    kpis=[
        "conversion_rate",
        "avg_order_value",
        "customer_lifetime_value",
        "email_click_rate",
        "returns_rate",
    ],
)

HEALTHCARE = DomainContext(
    name="healthcare",
    # Typical population health clustering dimensions: utilization + risk + outcomes
    features=[
        "age",
        "risk_score",
        "visits_12m",
        "readmissions_12m",
        "med_adherence_rate",
    ],
    kpis=[
        "risk_score",
        "visits_12m",
        "readmissions_12m",
        "avg_cost_12m",
        "med_adherence_rate",
    ],
)


def get_context(name: str) -> DomainContext:
    name = name.strip().lower()
    if name == "finance":
        return FINANCE
    if name == "marketing":
        return MARKETING
    if name == "healthcare":
        return HEALTHCARE
    raise ValueError(f"Unsupported context: {name}")
