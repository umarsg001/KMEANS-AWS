"""End-to-end pipeline orchestration."""

from __future__ import annotations

from pathlib import Path

import pandas as pd

from .context import get_context
from .data_loader import load_csv
from .kmeans_model import compute_inertia_curve, fit_kmeans, recommend_k_elbow
from .preprocess import preprocess
from .visualize import plot_clusters_2d, plot_elbow


def summarize_clusters(df: pd.DataFrame, label_col: str, kpi_cols: list[str]) -> pd.DataFrame:
    existing = [c for c in kpi_cols if c in df.columns]
    if not existing:
        # fall back: summarize all numeric cols
        existing = df.select_dtypes(include="number").columns.tolist()
        existing = [c for c in existing if c != label_col]

    summary = (
        df.groupby(label_col)[existing]
        .mean(numeric_only=True)
        .reset_index()
        .sort_values(by=label_col)
    )
    return summary


def run_pipeline(
    data_path: Path,
    context: str,
    outdir: Path,
    k: int | None = None,
) -> None:
    """Run clustering with elbow method + output artifacts."""
    df = load_csv(data_path)
    ctx = get_context(context)

    # Preprocess features based on chosen context
    prep = preprocess(df, ctx.features)

    # Elbow method (only used if k is not specified)
    ks, inertias = compute_inertia_curve(prep.X, k_min=2, k_max=min(10, max(2, len(df) - 1)))
    elbow_path = outdir / "elbow.png"
    plot_elbow(ks, inertias, elbow_path)

    if k is None:
        k = recommend_k_elbow(ks, inertias)

    result = fit_kmeans(prep.X, k=k)

    # Attach labels
    labeled = df.copy()
    labeled["Cluster"] = result.labels

    # Charts
    plot_clusters_2d(prep.X, result.labels, outdir / "clusters_2d.png")

    # Summaries and exports
    cluster_summary = summarize_clusters(labeled, "Cluster", ctx.kpis)

    labeled.to_csv(outdir / "labeled_data.csv", index=False)
    cluster_summary.to_csv(outdir / "cluster_summary.csv", index=False)

    # Print quick console report (useful for your submission log)
    print(f"Context: {context}")
    print(f"Recommended/Used k: {k}")
    print("Artifacts:")
    print(f"  - {elbow_path}")
    print(f"  - {outdir / 'clusters_2d.png'}")
    print(f"  - {outdir / 'cluster_summary.csv'}")
    print(f"  - {outdir / 'labeled_data.csv'}")
