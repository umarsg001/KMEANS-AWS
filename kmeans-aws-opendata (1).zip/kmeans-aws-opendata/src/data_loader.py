"""Data loading utilities.

This project assumes the dataset is already available as a local CSV.
For AWS Open Data (S3) datasets, download/prepare a CSV extract first, then pass it via --data.
"""

from __future__ import annotations

from pathlib import Path

import pandas as pd


def load_csv(path: Path) -> pd.DataFrame:
    """Load a CSV file into a DataFrame.

    Args:
        path: Path to the CSV file.

    Returns:
        pandas DataFrame

    Raises:
        FileNotFoundError: if path does not exist
        ValueError: if the file cannot be read as a CSV
    """
    if not path.exists():
        raise FileNotFoundError(f"CSV not found: {path}")

    try:
        df = pd.read_csv(path)
    except Exception as exc:
        raise ValueError(f"Failed to read CSV: {path}") from exc

    if df.empty:
        raise ValueError("CSV loaded but contains no rows")

    return df
