"""K-Means model utilities, including elbow method support."""

from __future__ import annotations

from dataclasses import dataclass

import numpy as np
from sklearn.cluster import KMeans


@dataclass
class KMeansResult:
    labels: np.ndarray
    model: KMeans


def fit_kmeans(X: np.ndarray, k: int, random_state: int = 42) -> KMeansResult:
    if k < 2:
        raise ValueError("k must be >= 2")

    model = KMeans(n_clusters=k, random_state=random_state, n_init="auto")
    labels = model.fit_predict(X)
    return KMeansResult(labels=labels, model=model)


def compute_inertia_curve(
    X: np.ndarray,
    k_min: int = 2,
    k_max: int = 10,
    random_state: int = 42,
) -> tuple[list[int], list[float]]:
    """Compute inertia for a range of k values.

    Inertia is the sum of squared distances to the nearest cluster center.
    Lower is better, but inertia always decreases as k increases; the "elbow"
    is a practical trade-off point.
    """
    if k_max <= k_min:
        raise ValueError("k_max must be > k_min")

    ks: list[int] = []
    inertias: list[float] = []

    for k in range(k_min, k_max + 1):
        model = KMeans(n_clusters=k, random_state=random_state, n_init="auto")
        model.fit(X)
        ks.append(k)
        inertias.append(float(model.inertia_))

    return ks, inertias


def recommend_k_elbow(ks: list[int], inertias: list[float]) -> int:
    """Heuristic elbow recommendation using maximum second derivative.

    This is a simple, explainable approach suitable for assignments:
    - Compute discrete 2nd differences of inertia
    - Choose k at the largest curvature (largest 2nd difference magnitude)

    If the curve is nearly linear, it defaults to the smallest k.
    """
    if len(ks) != len(inertias) or len(ks) < 3:
        return ks[0]

    y = np.array(inertias, dtype=float)
    # second discrete difference
    d2 = y[:-2] - 2 * y[1:-1] + y[2:]
    idx = int(np.argmax(d2))
    # d2 corresponds to ks[1:-1]
    return ks[idx + 1]
